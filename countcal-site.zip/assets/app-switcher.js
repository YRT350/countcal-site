
document.querySelectorAll('.app-switcher').forEach(disclosure => {
  const trigger = disclosure.querySelector('summary');
  const links = [...disclosure.querySelectorAll('nav a')];
  const close = () => { disclosure.open = false; };
  document.addEventListener('click', event => {
    if (!disclosure.contains(event.target)) close();
  });
  disclosure.addEventListener('focusout', () => {
    setTimeout(() => { if (!disclosure.contains(document.activeElement)) close(); }, 0);
  });
  disclosure.addEventListener('keydown', event => {
    if (event.key === 'Escape' && disclosure.open) {
      event.preventDefault(); close(); trigger.focus(); return;
    }
    if (event.target === trigger && ['ArrowDown', 'ArrowUp'].includes(event.key)) {
      event.preventDefault(); disclosure.open = true;
      links[event.key === 'ArrowDown' ? 0 : links.length - 1].focus(); return;
    }
    const index = links.indexOf(event.target);
    if (index < 0) return;
    const next = {ArrowDown: (index + 1) % links.length,
      ArrowUp: (index + links.length - 1) % links.length, Home: 0, End: links.length - 1}[event.key];
    if (next !== undefined) { event.preventDefault(); links[next].focus(); }
  });
  links.forEach(link => link.addEventListener('click', close));
});
